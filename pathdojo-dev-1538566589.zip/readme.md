Motivation:

Histology is pattern recognition with reinforcement

Strategy:

This is a tool to create bite-sized custom image quizzes. 

Additional functions: 
- Read simple disease refreshers
- Inspect immunohistochemistry and differentials
- Generate a differentials quiz-within-a-quiz for comparing like-diseases instantly